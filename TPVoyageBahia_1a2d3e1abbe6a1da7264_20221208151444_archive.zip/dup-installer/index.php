<?php

echo "Please browse to the 'installer.php' from your web browser to proceed with your install!";
die;
